import json
from pathlib import Path


def evaluate_quantum(example: dict) -> dict:
    distribution = example["input"]["output_distribution"]
    threshold = example["knowledge_block"]["threshold"]
    computed_value = distribution.get("00", 0) + distribution.get("11", 0)
    decision = "PASS" if computed_value >= threshold else "FAIL"
    return {"computed_value": round(computed_value, 6), "decision": decision}


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[2]
    example_path = root / "use-cases" / "quantum" / "examples" / "simple_quantum_decision.json"
    with example_path.open("r", encoding="utf-8") as f:
        example = json.load(f)
    print(json.dumps(evaluate_quantum(example), indent=2))
