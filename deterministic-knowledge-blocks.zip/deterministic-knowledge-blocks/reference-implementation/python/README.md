# Python Reference Implementation

This folder contains a minimal evaluator for demonstration purposes.

It is not production ready.
