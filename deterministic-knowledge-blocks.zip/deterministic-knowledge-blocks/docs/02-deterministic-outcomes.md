# Deterministic Outcomes
